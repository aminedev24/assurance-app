window.onload = ()=>{
    if(localStorage.getItem('users')!= null){
        localStorage.getItem('users');
    }
}